function [net, Val_accuracy, d1, d2] =  DLTraining(training_data_path)

    %Importing Folder containing the labeled files. 
    %The function imageDatastore() generates a database of images 
    imds = imageDatastore(training_data_path, 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
    %countLabels=countEachLabel(imds);

    %Dividing out dataset into Training and Validation set. This should be
    %roughly in the ratio 70:30
    numTrainFiles = 700;
    [TrainingSet, ValidationSet]= splitEachLabel(imds, numTrainFiles, 'randomize');

    %Input layer size is determined by the size of image. Therefore we extract
    %the size in x,y,z dimensions. Z-dimension specify the number of color
    %features in an image.
    image_size=readimage(imds,1);
    d1=size(image_size,1);
    d2=size(image_size,2);
    d3=size(image_size,3);

    %We now define the meta-structure of our Deep Learning Neural Network
    %General Architecture:
    %Conv_Layer->BatchNorm_Layer->ReLU_Layer->Pooling_Layer
    %For our network, we have added 5 Layers between Input and output layer
    % Input_Layer--L1--L2--L3--L4--L5--Output_Layer

    layers = [
        imageInputLayer([d1 d2 d3])

        convolution2dLayer(3,8,'Padding',1)
        batchNormalizationLayer
        reluLayer

        maxPooling2dLayer(2,'Stride',2)

        convolution2dLayer(3,16,'Padding',1)
        batchNormalizationLayer
        reluLayer

        maxPooling2dLayer(2,'Stride',2)

        convolution2dLayer(3,32,'Padding',1)
        batchNormalizationLayer
        reluLayer

        maxPooling2dLayer(2,'Stride',2)

        convolution2dLayer(3,32,'Padding',1)
        batchNormalizationLayer
        reluLayer

        maxPooling2dLayer(2,'Stride',2)


        convolution2dLayer(3,16,'Padding',1)
        batchNormalizationLayer
        reluLayer

        fullyConnectedLayer(3)
        softmaxLayer
        classificationLayer];

    %Options specify the hyperparameters needed to train our network
    options = trainingOptions('sgdm', ...
        'MaxEpochs',8, ...
        'ValidationData',ValidationSet, ...
        'ValidationFrequency',30, ...
        'Verbose',false, ...
        'Plots','training-progress');

    %Running the DNN to train on our dataset
    net = trainNetwork(TrainingSet,layers,options);

    %Calculating accuracy on validation set
    YPred = classify(net,ValidationSet);
    YValidation = ValidationSet.Labels;
    Val_accuracy = sum(YPred == YValidation)/numel(YValidation)

end







